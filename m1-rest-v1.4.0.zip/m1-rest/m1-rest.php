<?php
/**
 * Plugin Name: M1 REST API
 * Description: Mindhikers M1 REST API endpoints for homepage, products, and blog
 * Author: Mindhikers
 * Version: 1.4.0
 */

declare(strict_types=1);

defined('ABSPATH') || exit;

// Plugin directory
define('M1_REST_DIR', plugin_dir_path(__FILE__));

// Force remove old mu-plugins files
$old_mu_files = [
    WPMU_PLUGIN_DIR . '/m1-rest-loader.php',
    WPMU_PLUGIN_DIR . '/m1-rest/helpers.php',
    WPMU_PLUGIN_DIR . '/m1-rest/homepage.php',
    WPMU_PLUGIN_DIR . '/m1-rest/product.php',
    WPMU_PLUGIN_DIR . '/m1-rest/blog.php',
    WPMU_PLUGIN_DIR . '/m1-rest/revalidate.php',
    WPMU_PLUGIN_DIR . '/m1-rest/load.php',
];

foreach ($old_mu_files as $file) {
    if (file_exists($file)) {
        @unlink($file);
    }
}

// Remove old directory
if (is_dir(WPMU_PLUGIN_DIR . '/m1-rest')) {
    @rmdir(WPMU_PLUGIN_DIR . '/m1-rest');
}

// Load all REST endpoint modules
require_once M1_REST_DIR . 'helpers.php';
require_once M1_REST_DIR . 'homepage.php';
require_once M1_REST_DIR . 'product.php';
require_once M1_REST_DIR . 'blog.php';
require_once M1_REST_DIR . 'revalidate.php';
