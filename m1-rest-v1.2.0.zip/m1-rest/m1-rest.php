<?php
/**
 * Plugin Name: M1 REST API
 * Description: Mindhikers M1 REST API endpoints for homepage, products, and blog
 * Author: Mindhikers
 * Version: 1.2.0
 */

declare(strict_types=1);

defined('ABSPATH') || exit;

// Plugin directory
define('M1_REST_DIR', plugin_dir_path(__FILE__));

// Load all REST endpoint modules
require_once M1_REST_DIR . 'helpers.php';
require_once M1_REST_DIR . 'homepage.php';
require_once M1_REST_DIR . 'product.php';
require_once M1_REST_DIR . 'blog.php';
require_once M1_REST_DIR . 'revalidate.php';
