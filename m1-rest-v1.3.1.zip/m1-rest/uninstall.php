<?php
// Cleanup on uninstall - remove any mu-plugins files
if (defined('WP_UNINSTALL_PLUGIN')) {
    // Remove old mu-plugins files if they exist
    $mu_plugins = WPMU_PLUGIN_DIR;
    if (is_dir($mu_plugins)) {
        $files = [
            $mu_plugins . '/m1-rest-loader.php',
            $mu_plugins . '/m1-rest/helpers.php',
            $mu_plugins . '/m1-rest/homepage.php',
            $mu_plugins . '/m1-rest/product.php',
            $mu_plugins . '/m1-rest/blog.php',
            $mu_plugins . '/m1-rest/revalidate.php',
        ];
        foreach ($files as $file) {
            if (file_exists($file)) {
                unlink($file);
            }
        }
        // Remove old directory
        if (is_dir($mu_plugins . '/m1-rest')) {
            rmdir($mu_plugins . '/m1-rest');
        }
    }
}
